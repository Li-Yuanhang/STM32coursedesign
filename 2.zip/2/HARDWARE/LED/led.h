#ifndef __LED_H
#define __LED_H	 

#include "sys.h"

//LED�˿ڶ���
#define LED0 PEout(0)

void LED_Init(void);//��ʼ��	

#endif

















